# OmniboxWriting
- input "ow" in your omnibox
- click "tab"
- then write in omnibox.
- click "enter" when you finish
- check your writings on options page.
- read more on options page.
